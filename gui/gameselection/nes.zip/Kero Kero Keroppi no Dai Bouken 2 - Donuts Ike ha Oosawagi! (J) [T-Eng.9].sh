cd /home/pi/RomDownloader/Temp/Roms/Items_To_Download/nes
echo "enter link here" >> itemlist.txt