cd /home/pi/RomDownloader/Temp/Roms/Items_To_Download/nes
echo "archive.org/download/gb_20201207/Complete%20Rom%20Sets/nes.zip/nes%2FMajou%20Densetsu%202%20-%20Daimashikyou%20Galious%20%28J%29%20%5BT-Eng0.10%5D.nes" >> itemlist.txt



#This is something your not meant to see
#To make the downloadable files, i used a task automater to copy the commands to here, and the size is how i tell what is updated or not.
# I need this to be 2 KB instead of 1 KB so i can tell it worked
#__  __           _                                     
#|  \/  | __ _  __| | ___                                
#| |\/| |/ _` |/ _` |/ _ \                               
#| |  | | (_| | (_| |  __/                               
#|_|  |_|\__,_|\__,_|\___|                               
#| |__  _   _                                            
#| '_ \| | | |                                           
#| |_) | |_| |                                           
#|_.__/_\__, | _ _         _  _    __    ___   ___ ____  
#  ___| |___(_) | |_   _ _| || |_ / /_  ( _ ) / _ \___ \ 
# / __| '_ \| | | | | | |_  ..  _| '_ \ / _ \| | | |__) |
#| (__| | | | | | | |_| |_      _| (_) | (_) | |_| / __/ 
# \___|_| |_|_|_|_|\__, | |_||_|  \___/ \___/ \___/_____|
#                  |___/               